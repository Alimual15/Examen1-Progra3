CREATE DATABASE ECOCOLOGIAVERDE
drop table Materiales

CREATE TABLE Materiales (
  id INT PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  tipo VARCHAR(255) NOT NULL,
  descripci�n TEXT NOT NULL,
  fase_de_reciclaje VARCHAR(255) NOT NULL
)
drop table FasesDeReciclaje

CREATE TABLE FasesDeReciclaje (
  id INT PRIMARY KEY,
  nombre VARCHAR(255) NOT NULL,
  descripci�n TEXT NOT NULL,
  materiales_relacionados VARCHAR(255) NOT NULL
)

CREATE TABLE Infografias (
  id INT PRIMARY KEY,
  t�tulo VARCHAR(255) NOT NULL,
  descripci�n TEXT NOT NULL,
  imagen VARCHAR(255) NOT NULL,
  materiales_relacionados VARCHAR(255) NOT NULL
)