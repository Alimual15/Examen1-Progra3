// index.html
document.querySelector('button').addEventListener('click', function() {
    alert('¡Gracias por interesarte en el reciclaje!');
  });
  
  // fases.html
  document.querySelectorAll('ol li').forEach(function(li) {
    li.addEventListener('mouseover', function() {
      li.style.backgroundColor = '#f2f2f2';
    });
    li.addEventListener('mouseout', function() {
      li.style.backgroundColor = '';
    });
  });
  
  // materiales.html
  document.querySelectorAll('img').forEach(function(img) {
    img.addEventListener('click', function() {
      alert(`¡Este ${img.alt} es reciclable!`);
    });
  });
  
  // infografias.html
  document.querySelectorAll('img').forEach(function(img) {
    img.addEventListener('mouseover', function() {
      img.style.transform = 'scale(1.1)';
    });
    img.addEventListener('mouseout', function() {
      img.style.transform = '';
    });
  });